﻿using System.Web;
using System.Web.Mvc;

namespace Onebeat_HRJ
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
